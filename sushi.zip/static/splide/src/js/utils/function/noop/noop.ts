/**
 * No operation.
 */
export const noop = (): void => {}; // eslint-disable-line no-empty-function, @typescript-eslint/no-empty-function
